# Goosed Tunnel

A self-contained, single-binary solution for creating secure Tailscale tunnels to Goose AI agents. This tool embeds Tailscale functionality directly using the `tsnet` library, eliminating the need for a separate `tailscaled` daemon.

## Features

- **Single Binary**: All functionality in one ~19MB executable
- **Embedded Tailscale**: Uses `tsnet` library for built-in Tailscale networking
- **Userspace Networking**: No root privileges required
- **Automatic Setup**: Handles authentication and network configuration
- **Flexible Modes**: Can start goosed or proxy to existing services
- **QR Code Support**: Generate QR codes for mobile client configuration
- **Cross-Platform**: Builds for Linux, macOS, and Windows
- **HTTPS Support**: Automatic TLS certificates via Tailscale

## Quick Start

```bash
# Clone the repository (or download the files)
git clone https://github.com/yourusername/goosed-tunnel.git
cd goosed-tunnel

# Build the binary
make

# Run it
./goosed-tunnel
```

## Installation

### From Source

```bash
# Download and build
git clone https://github.com/yourusername/goosed-tunnel.git
cd goosed-tunnel
make

# Optionally install system-wide
sudo make install
```

### Pre-built Binaries

Build for all platforms:

```bash
make build-all
# Binaries will be in the dist/ directory
```

## Usage

### Basic Usage

```bash
# Start tunnel with goosed
./goosed-tunnel

# Use a custom hostname
./goosed-tunnel --hostname my-goose

# Proxy to existing service (don't start goosed)
./goosed-tunnel --no-goosed --port 8080

# Verbose mode for debugging
./goosed-tunnel --verbose
```

### Command-Line Options

```
--port PORT              Local port for goosed server (default: 62996)
--hostname NAME          Tailscale hostname (default: goosed-tunnel)
--state-dir PATH         Directory for Tailscale state (default: ~/.local/share/goosed-tunnel)
--no-goosed              Don't start goosed (proxy to existing service)
--goosed-path PATH       Path to goosed executable (default: goosed)
--no-qr                  Don't display QR code
--verbose                Enable verbose logging
--version                Show version and exit
```

### Examples

#### Proxy to Existing Service

If you already have a service running:

```bash
# Proxy to a service on port 8080
./goosed-tunnel --no-goosed --port 8080
```

#### Custom Goosed Location

```bash
# Use goosed from a specific path
./goosed-tunnel --goosed-path /opt/goose/bin/goosed
```

#### Different State Directory

```bash
# Use a custom state directory
./goosed-tunnel --state-dir /var/lib/goosed-tunnel
```

## How It Works

1. **Initialization**: Creates a Tailscale node using the embedded `tsnet` library
2. **Authentication**: If needed, provides an auth URL (opens automatically)
3. **Service Start**: Optionally starts goosed with a secure random key
4. **Proxy Setup**: Establishes HTTP/HTTPS reverse proxy from Tailscale to local service
5. **Connection Info**: Displays URLs and optionally generates QR code

## Building

### Requirements

- Go 1.23 or later
- Make (optional, but recommended)

### Build Commands

```bash
# Simple build
go build -o goosed-tunnel .

# Or using make
make                    # Build for current platform
make build-debug        # Build with debug symbols
make build-all          # Build for all platforms
make clean              # Clean build artifacts
```

### Build Targets

The Makefile supports building for:
- Linux (AMD64, ARM64)
- macOS (AMD64, ARM64/Apple Silicon)
- Windows (AMD64)

## Dependencies

### Build Dependencies

- Go 1.23+
- Internet connection (to download Go modules)

### Runtime Dependencies

#### Required (unless using --no-goosed)
- `goosed` - The Goose AI daemon

#### Optional
- `qrencode` - For QR code generation
  ```bash
  # macOS
  brew install qrencode
  
  # Linux
  apt-get install qrencode
  ```

### Check Dependencies

```bash
make check-deps
```

## State Management

The tunnel stores Tailscale state in:
- Default: `~/.local/share/goosed-tunnel/`
- Custom: Use `--state-dir` flag

This includes:
- Tailscale node keys
- Authentication state
- Network configuration

## Security

- **Encryption**: All traffic flows through Tailscale's encrypted WireGuard tunnels
- **Authentication**: Random secret keys generated for each goosed session
- **No Open Ports**: Services only accessible via Tailscale network
- **Userspace**: Runs entirely in userspace without root privileges

## Architecture

```
┌─────────────────┐
│  Mobile/Remote  │
│     Client      │
└────────┬────────┘
         │ HTTPS/HTTP
         ▼
┌─────────────────┐
│   Tailscale     │
│    Network      │
└────────┬────────┘
         │ WireGuard
         ▼
┌─────────────────┐
│  goosed-tunnel  │
│   (tsnet node)  │
├─────────────────┤
│  HTTP/S Proxy   │
└────────┬────────┘
         │ localhost
         ▼
┌─────────────────┐
│     goosed      │
│   (AI Agent)    │
└─────────────────┘
```

## Troubleshooting

### Goosed not found

```bash
# Check if goosed is in PATH
which goosed

# Or specify path explicitly
./goosed-tunnel --goosed-path /path/to/goosed
```

### Authentication issues

1. Ensure you're logged into Tailscale
2. Check the auth URL provided
3. Verify network connectivity

### QR code not displaying

```bash
# Install qrencode
brew install qrencode  # macOS
apt-get install qrencode  # Debian/Ubuntu

# Or disable QR codes
./goosed-tunnel --no-qr
```

### Port already in use

```bash
# Use a different port
./goosed-tunnel --port 8080
```

## Development

### Project Structure

```
goosed-tunnel/
├── main.go           # All application code
├── go.mod            # Go module definition
├── go.sum            # Dependency checksums
├── Makefile          # Build automation
└── README.md         # This file
```

### Testing

```bash
# Test the build
make test

# Run with verbose logging
make run-verbose

# Check binary info
make info
```

### Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## Comparison with Alternatives

| Feature | goosed-tunnel | tailscaled + launcher | ngrok |
|---------|--------------|----------------------|-------|
| Single Binary | ✅ 19MB | ❌ 30MB + launcher | ✅ |
| Self-Hosted | ✅ | ✅ | ❌ |
| No Account Limits | ✅ | ✅ | ❌ (free tier limited) |
| E2E Encryption | ✅ | ✅ | ✅ |
| Root Required | ❌ | ❌ | ❌ |
| Embedded Networking | ✅ | ❌ | N/A |

## License

[Add your license here]

## Acknowledgments

- Built with [Tailscale's tsnet](https://pkg.go.dev/tailscale.com/tsnet)
- Designed for [Goose AI](https://github.com/block/goose)

## Support

For issues, questions, or contributions:
- Open an issue on GitHub
- Check existing issues for solutions
- Review the troubleshooting section above
